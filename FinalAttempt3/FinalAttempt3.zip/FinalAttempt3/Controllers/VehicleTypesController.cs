﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FinalAttempt3.Models;

namespace FinalAttempt3.Controllers
{
    public class VehicleTypesController : Controller
    {
        private VehicleModel db = new VehicleModel();

        // GET: VehicleTypes
        public ActionResult Index()
        {
            return View(db.VehicleTypes.ToList());
        }

        // GET: VehicleTypes/Details/5
        public ActionResult Details(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VehicleType vehicleType = db.VehicleTypes.Find(id);
            if (vehicleType == null)
            {
                return HttpNotFound();
            }
            return View(vehicleType);
        }

        // GET: VehicleTypes/Create
        public ActionResult Create()
        {

            VehicleType item = new VehicleType() { CreateDate = DateTime.Now.ToLocalTime(), EditDate = DateTime.Now.ToLocalTime() };
            return View(item);
        }

        // POST: VehicleTypes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "VehicleTypeId,VehicleTypeName,CreateDate,EditDate")] VehicleType vehicleType)
        {

            try { 
                if (ModelState.IsValid)
                {
                    db.VehicleTypes.Add(vehicleType);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(vehicleType);

            }
            catch (Exception ex)
            {
                while (ex.InnerException != null) ex = ex.InnerException;
                return View("Error", new HandleErrorInfo(ex, "VehicleTypesController", "Create"));
            }

}

        // GET: VehicleTypes/Edit/5
        public ActionResult Edit(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VehicleType vehicleType = db.VehicleTypes.Find(id);
            vehicleType.EditDate = DateTime.Now.ToLocalTime();
            if (vehicleType == null)
            {
                return HttpNotFound();
            }
            return View(vehicleType);
        }

        // POST: VehicleTypes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "VehicleTypeId,VehicleTypeName,CreateDate,EditDate")] VehicleType vehicleType)
        {

            try {
                if (ModelState.IsValid)
                    {
                        db.Entry(vehicleType).State = EntityState.Modified;
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    return View(vehicleType);
                }
            catch (Exception ex)
            {
                while (ex.InnerException != null) ex = ex.InnerException;
                return View("Error", new HandleErrorInfo(ex, "VehicleTypesController", "Edit"));
            }


}

// GET: VehicleTypes/Delete/5
public ActionResult Delete(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            VehicleType vehicleType = db.VehicleTypes.Find(id);
            if (vehicleType == null)
            {
                return HttpNotFound();
            }
            return View(vehicleType);
        }

        // POST: VehicleTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(decimal id)
        {
            try
            { 
            VehicleType vehicleType = db.VehicleTypes.Find(id);
            db.VehicleTypes.Remove(vehicleType);
            db.SaveChanges();
            return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                while (ex.InnerException != null) ex = ex.InnerException;
                return View("Error", new HandleErrorInfo(ex, "VehicleTypesController", "Delete"));
            }

}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
